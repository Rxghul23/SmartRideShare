# Smart RideShare

SMART RIDESHARE - EXECUTION PROCEDURE

A. PREREQUISITES (Windows x64)
1. Python 3.11 installed and available as python on PATH.
2. MySQL Server 8.0 binaries at C:\Program Files\MySQL\MySQL Server 8.0.
   The scripts create a separate local database instance on port 3307.
   If MySQL is installed elsewhere, change mysqlBase in scripts/setup.ps1 and the mysqld.exe path in scripts/start.ps1.
3. Internet access for first setup (Java, Maven, Tomcat and Python dependencies), map tiles and OSRM road routes.
4. Free local ports 3307 (MySQL), 5001 (Python), 8080 and 8005 (Tomcat).
5. Optional: Eclipse IDE for Enterprise Java and Web Developers; Chrome for browser tests.

B. FIRST RUN
1. Extract the ZIP. Copy the complete 04_Project_Code/SmartRideShare folder to C:\SmartRideShare.
   Use a short path without spaces because the supplied Windows process-launch scripts assume this.
2. Open PowerShell in C:\SmartRideShare.
3. Run:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\setup.ps1
4. Setup downloads the pinned JDK, Maven and Tomcat into .tools, installs Python packages, builds the WAR, starts a dedicated MySQL instance, seeds the sample records and applies all three SQL files.
5. Wait for: SmartRide is running.
6. Open http://localhost:8080/smartride/ (or http://127.0.0.1:8080/smartride/).
7. Open the newly generated LOCAL-LOGIN.txt for the local password. Example accounts:
   admin@smartride.local (administrator)
   aarav@smartride.local (employee)
   priya@smartride.local (employee / driver)
   These credentials are generated per installation, not shipped in the ZIP.

C. SUBSEQUENT RUNS / STOP
Double-click START-SMARTRIDE.cmd to run the project.
Double-click STOP-SMARTRIDE.cmd to stop only this project's services.
Do not delete .local-config.json after initialisation; it contains the credentials for that local database instance.

D. CLASSROOM WALKTHROUGH
1. Use separate normal and incognito browser sessions for two different employee accounts.
2. Driver: offer Velachery -> Tidel Park, tomorrow 09:00, two passenger seats. Wait for route and price calculation before publishing.
3. Passenger: request the same route and time. Save the request and open AI matches.
4. The driver's offer should appear on the next active five-second refresh. Book a seat.
5. My journeys -> Payment -> Pay now. Test mode records the payment without charging money; download the receipt.
6. Open Ride chat in both accounts and exchange a pickup message.
7. Cancel the passenger booking to demonstrate seat restoration and the test refund.
8. Open Analytics, then use the administrator account for user management, service health and CSV reports.
9. Completion is allowed only after departure; a completed booking accepts one feedback submission.
Old seeded offers may be in the past. Create a fresh future ride for the demonstration. A user cannot book their own ride.

E. ECLIPSE
After setup, import C:\SmartRideShare as an Existing Maven Project.
Use .tools\jdk-21.0.8+9 as the JDK (source target Java 17).
The project name must be SmartRideShare for the supplied launch configurations.
Run SmartRide Build.launch / SmartRide Start.launch as External Tools.
See docs/ECLIPSE-SETUP.md for the full procedure. Do not run a second Tomcat on the same port.

F. TESTS
In PowerShell from the project directory:
  . .\scripts\env.ps1
  & .\scripts\build.ps1
  Push-Location ml-service
  python -m unittest test_app
  Pop-Location
After Tomcat finishes redeploying and the home page loads:
  python scripts/integration_test.py
Optional browser checks (requires Chrome at its standard Windows path):
  python -m pip install --target .tools/python -r requirements-validation.txt
  python scripts/map_realtime_test.py
  python scripts/chat_test.py
  python scripts/payment_test.py
Existing evidence records 59 passing automated checks on the development machine. External routing can time out; use Retry route and rerun the affected check. The ZIP is not an offline dependency bundle.

G. TROUBLESHOOTING
Route unavailable: check internet and click Retry route. No stale fare should remain.
No matches: check different accounts, future times, remaining seats and both location coordinates.
Database fails: check MySQL installation path and port 3307; read tmp/mysql-error.log.
App unavailable: read tmp/tomcat-error.log and tmp/ml-error.log.
404 immediately after build: allow Tomcat to complete WAR redeployment, then refresh.
The demo video and report can be reviewed without installing or running the application.
